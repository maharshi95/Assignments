
public class AirConditioner extends Appliance {
    public AirConditioner() {
        super("AirConditioner", ApplianceType.AIR_CONDITIONER);
    }
}
