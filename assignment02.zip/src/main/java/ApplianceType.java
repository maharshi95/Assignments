public enum ApplianceType {
    WATER_HEATER,
    AIR_CONDITIONER,
    COOKING_OVEN
}
