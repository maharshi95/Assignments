
public class BadScheduleException extends Exception {
     public BadScheduleException(String msg) {
        super(msg);
     }
}
