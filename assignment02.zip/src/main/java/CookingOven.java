
public class CookingOven extends Appliance {
    public CookingOven() {
        super("CookingOven", ApplianceType.COOKING_OVEN);
    }
}
